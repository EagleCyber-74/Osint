<pre>
 =============================================
|                                             |
|  _________________________________________  |
| |                                         | |
| |             <b>INTRODUCTION</b>                | |
| |            ——————————————               | |
| |   This is A Python & Bash Programming   | |    
| |BasedTermux-Tool Created By <a href="https://www.facebook.com/cracker911181">CRACKER911181</a>| |
| |   This Tool Created For Hacking and     | |
| | Pentesting.If You Use This Tool To Evil | |
| |  Purpose,I'm Not Responsible For That.  | |
| |            <a href="https://play.google.com/store/apps/details?id=com.termux">Termux</a> User only             | |
| |_________________________________________| |
|                                             |
|  _________________________________________  |
| |                                         | |
| |		  | @   @ |		    | |
| |                ———————		    | |
| |               |cracker|		    | |	  
| |                ———————		    | |
| |           /\  |       |   /\\	    | |
| |          // \——       ———/  \\	    | |  
| |     ____// crack your world  \\___ 	    | |
| |			                    | |
| |  |==================================|   | |
| |  |        DON'T COPY MY STYLE       |   | |
| |  |==================================|   | |
| |                                         | |
| |_________________________________________| |
|                                             |
|  _________________________________________  |
| |                                         | |
| |        <b>CRACKER ALL IN ONE TOOL</b>          | |
| |                                         | |
| |               <b>VERSION</b>                   | |
| |              __________                 | |
| |                                         | |
| | 4.3 ;     Public CCTV Hack Tool Added!  | |
| |_________________________________________| |
|                                             |
|  _________________________________________  | 
| |                                         | |
<!--| |        CRACKER ALL IN ONE TOOL         | |-->| |             <b>INSTALLATION</b>                | |
| |             _____________               | |
| |                                         | |
| | For First Time Installtion:             | |
| |   $ apt update -y                       | |
| |   $ apt upgrade -y                      | |
| |   $ pkg install git -y                  | |
| |   $ git clone <a href="https://github.com/cracker911181/Cracker-Tool">https://github.com/cracke</a> | |
| |                   <a href="https://github.com/cracker911181/Cracker-Tool">r911181/Cracker911181</a> | |
| |                                         | |
| | Any Time Run Code:                      | |
| |  $ cd Cracker-Tool                      | |
| |  $ Python cracker-main.py               | |
| |                                         | |
| |                                         | |
| | > Git Clone Link:                       | |
| |               <a href="https://github.com/cracker911181/Cracker-Tool">Link</a>                      | |
| |_________________________________________| |
|                                             |
|  _________________________________________  |
| |                                         | |
| |               <b>FEATURES</b>                  | |
| |              ___________                | |
| |                                         | |
| |         1. IP Tool                      | |
| |         2. Subdomain Scanner            | |
| |         3. Ddos Attack Tool             | |
| |         4. Admin Finder                 | |
| |         5. Has Cracker                  | |
| |         6. Video Downloader             | |
| |         7. BD Cloner                    | |
| |         8. SQL Injection Tool           | |
| |         9. Text To Voice Convertor      | |
| |        10. Python Obfuscator            | |
| |        11. Telegram Kit                 | |
| |        12. Termux Framework             | |
| |        13. Kali Nethunter Installer     | |
| |        14. Termux Tool                  | |
| |        15. URL Changer                  | |
| |        16. URL Shortner                 | |
| |        17. WEB Tool                     | |
| |	   18. Temp Mail		    | |
| |        19. Gmail Genaretor 		    | |
| |	   20. Public CCTV Hack		    | |
| |_________________________________________| |
|                                             |
 =============================================
</pre>


<br>
<div align="center">
<b>

> ONE LINE COMMAND


```
curl https://raw.githubusercontent.com/cracker911181/Cracker-Tool/main/crcu.py | python ; cd Cracker-Tool ; python cracker-main.py 
``` 
<br>

  
> SCREENSHORT


</b>
<img src="https://github.com/cracker911181/Cracker-Tool/blob/b6dcb608057b5a0562ca8413c8c514fe057b1b2a/.fucked/20211023_013550.jpg" />

<br>

<b><br>
  

> CONTACT INFO  

</b></div>
<pre>
<b> FB</b>       :          <a href="https://www.facebook.com/cracker911181"><i>Link</i></a>
<b> GitHub</b>   :          <a href="https://github.com/cracker911181"><i>Link</i></a>
<b> Telegram</b> :          <a href="https://t.me/cracker911181"><i>LINK</i></a> 
</pre>
