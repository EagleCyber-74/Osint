clear
pip install requests 
chmod +x *

mv fix.py .fix.py
mv colomn_cnt.py .colomn_cnt.py
mv waf-chack.py .waf-chack.py
mv dios.py .dios.py
mv mn.sh .mn.sh
