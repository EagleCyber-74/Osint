while True:
	oo=open("/data/data/com.termux/files/home/Cracker-Tool/.test/clnn.py","r")
	exec(oo.read())
