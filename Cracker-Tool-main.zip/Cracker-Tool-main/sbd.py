import time
while True:
	oo=open("/data/data/com.termux/files/home/Cracker-Tool/.test/sbdd.py","r")
	exec(oo.read())
	time.sleep(7)
	break
