cd
rm -rf $HOME/Cracker-Tool
echo 
echo "	Tool Updating"
echo

git clone https://github.com/cracker911181/Cracker-Tool
cd Cracker-Tool

echo
echo "		updated"
sleep 2.5

