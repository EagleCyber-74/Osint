# Coded by cracker 
# CRACKER911181  
 

import base64, codecs
magic = 'aW1wb3J0IHJhbmRvbSxzeXMsbG9nZ2luZwoKbG9nZ2luZy5iYXNpY0NvbmZpZyhsZXZlbD1sb2dnaW5nLklORk8pCgpkZWYgbWFpbihmaWxlcyxzdHJpbmcpOgoJcz1vcGVuKGZpb'
love = 'TImXF5lMJSxXPxXPKb9J10XPJMipvOcVTyhVUZ6PtxWrv5upUOyozDbo3WxXTxcXDbWpTIuCIgqPtyzo3VtnFOcovO6BtbWPKOyLF5upUOyozDbp3ElnJ5aYaWypTkuL2HbVvpvYP'
god = 'IiKS5yZXBsYWNlKCciJywnJykqaSkKCWZpbGU9IiIiCgoKCmQ9e307ZXhlYygiIi5qb2luKFtjaHIobGVuKGkpKSBmb3IgaSBpbiBkXSkpCgkiIiIuZm9ybWF0KHBlYSkKCW9wZW4'
destiny = 'bMzyfMKZhpzIjoTSwMFtvYaO5VvjvMJ5wYaO5VvxfVapvXF53pzy0MFuznJkyXDbXPaElrGbXPtygLJyhXUA5pl5upzq2JmSqYUA5pl5upzq2JmWqXDcyrTAypUD6PtyjpzyhqPtc'
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))
