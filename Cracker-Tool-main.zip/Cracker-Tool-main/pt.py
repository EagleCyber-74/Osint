
oo=open("ptt.py","r")
exec(oo.read())
