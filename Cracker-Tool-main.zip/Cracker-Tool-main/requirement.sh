pkg install figlet -y 
pip install requests
pip install mechanize

# remove play-store coution notice:
rm -rf /data/data/com.termux/files/usr/etc/motd-playstore

pkg install p7zip

pip install pyfiglet
pip install bs4
pip install lolcat
#pip install -i https://test.pypi.org/simple/ cracker-say
#pip install git+https://github.com/cracker911181/cracker_say
pip install cracker-saying
pip install cowsay 
pip install youtube_dl
pip install gTTS
pip install telethon
pip install python-telegram-bot

