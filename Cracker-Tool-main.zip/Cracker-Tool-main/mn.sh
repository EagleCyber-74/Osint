clear
python .fix.py
python .colomn_cnt.py
python .waf-chack.py
python .dios.py
sleep 7
